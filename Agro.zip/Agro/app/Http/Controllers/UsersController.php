<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// Добавляем из папки Models класс Post, исп use
use App\Models\Users;

// Добавялем обработчик ошибкок
use App\Http\Requests\ContactRequest;
use App\Http\Requests\AuthRequest;

// Хешированный пароль
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class UsersController extends Controller {
    public function submit(ContactRequest $req) {  // Request - позволяет нам подключиться к данным ($req - мб любое свойство, не обязательно $req)
         
        // dd($req); выводит все свойства отправленной формы

        // $validation = $req->validate([
        //     'login' => 'required|min:2|max:50',
        //     'name' => 'required|min:1|max:50',
        //     'email' => 'required|min:1|max:30',
        //     'pass' => 'required|min:3|max:20',
        // ]);

        // $table = $req->session()->get('name', 'default'); 

        // Добавление значений в БД
        $table = new Users();
        $table->login = $req->input('login');
        $table->name = $req->input('name');
        $table->email = $req->input('email');
        // $table->pass = Hash::make($req->input('pass'));
        $table->password = Hash::make($req->input('password'));


        // Сохранение сессии через глобальную переменную
        session([
            'login' =>  $req->input('login'), 
            'name' =>  $req->input('name'),
            'email' =>  $req->input('email') ]);

        $table->save();

     //   $table = $req->session()->all(); //Получение всех данных сеанса  

    //  dd ($table);


        // Редирект на главную
        return redirect('/lc');
       
    }

    public function AuthAdmin(AuthRequest $au) {
        $table = new Users();
        $log = $au->only([ 'login', 'password' ]);

        // $r = Auth::attempt($table);
        // dd($r);


        if (Auth::attempt($log)) {
            session([
                'login' =>  $au->input('login'),
            ]);
            return redirect('/lc');
        }
        // echo 'Не верный пароль';
        return redirect('/');
    }

    
    public function ExitSession() {
        session()->flush();

        return redirect('/');
    }


    public function JsonCodeUsers() {

        $json_code = Users::all();
        echo json_encode($json_code);

    } 

};