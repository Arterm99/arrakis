<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// Добавляем из папки Models класс Post, исп use
use App\Models\AdminPanel;

// Добавялем обработчик ошибкок
use App\Http\Requests\lcRequets;
use Illuminate\Support\Facades\Storage;

class AdminPanelController extends Controller {
    public function admin(lcRequets $row) {

        $tables = $row->validated();
        $previewImage = $tables['profile_image'];
        $img = Storage::put('/images', $previewImage);
        // Сокращенная запись
        // $table->profile_image = $adm->validated();
        // $table['profile_image'] = Storage::put('/images',  $table['profile_image']);

        
        $table = new AdminPanel();
        $table->login = session('login');
        $table->name = $row->input('name');
        $table->description = $row->input('description');
        $table->product = $row->input('product');
        // $table->properties = $row->input('properties');
        // $product = AdminPanel::create($row->all());
        $table->profile_image = $img;


        
        // dd($table->all());
        // dd($row->all());
      
        // Сохранение значений в БД
        $table->save();

        // Редирект на главную
        return redirect('/lc');
    }

        
    public function SubAdmin() {

        // НЕУДАЧНАЯ ПОПЫТКА СОЕДЕНИТЬСЯ С  aside.blade.php
        // return view('aside' , array('data' => 'AdminPanel::all()'));

        // return redirect('/lc');
    } 
   
    public function JsonCodeProduct() {

        $json_code = AdminPanel::all();
        echo json_encode($json_code);

    } 


}
