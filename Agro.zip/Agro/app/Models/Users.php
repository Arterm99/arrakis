<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    use HasFactory;

        // даем разрешение работать с базой
    protected $table = 'users';
    protected $guarded = [];  // Переменная $guarded говрит, что "защищать никакой атрибут не нужно"
}
