<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdminPanel extends Model
{
    use HasFactory;

            // даем разрешение работать с базой
            protected $table = 'admin_panels';
            // protected $img = 'admin_panels';
            protected $guarded = [];  // Переменная $guarded говрит, что "защищать никакой атрибут не нужно"          
}
