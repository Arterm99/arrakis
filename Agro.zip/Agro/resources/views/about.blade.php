<!-- Ссылка на общую html-разметку -->
@extends('layouts.app')

<!-- Начало/Конец кода -->
@section('title-block')О компании@endsection

<!-- Начало кода -->
@section('content')

    О компании

<!-- Конец кода -->
@endsection