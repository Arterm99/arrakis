<!-- Ссылка на общую html-разметку -->
@extends('layouts.app')

<!-- Начало/Конец кода -->
@section('title-block')Личный кабинет@endsection

<!-- Начало кода -->
@section('content')

<!-- Ошибки -->
@include('errors.errors')


    Личный кабинет

        <div style="margin: 3%">
            <form method="POST" action="/reg-lc" enctype="multipart/form-data">
            @csrf
                <p><select autofocus required name="product">
                <option selected disabled>Выберите товар</option>
                    <option value="Молоко">Молоко</option>
                    <option value="Сыры">Сыры</option>
                    <option value="Мясная продукция">Мясная продукция</option>
                    <option value="Фрукты">Фрукты</option>
                    <option value="Овощи">Овощи</option>
                </select></p>
                <input placeholder="Название товара" type="text" name="name" autofocus>
                <br />
                <textarea placeholder="Описание товара" type="text" name="description"> </textarea>
                <br />
                <input type="file" name="profile_image">
          
                <br />
                <input type="reset" value="Очистить"></p>
                <button class="btn btn-primary" type="submit">Добавить</button>
            </form>
        </div>


<!-- Конец кода -->
@endsection